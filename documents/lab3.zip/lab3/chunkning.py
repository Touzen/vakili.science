#!/usr/bin/python
# -*- coding: utf-8 -*-

###################################################
# Ett script som gör en väldigt enkel chunkning
# Skrivet av Maria Skeppstedt för:
# Språkteknologi - Mänskliga språk och datorer
###################################################

import pprint
import sys
import os
import nltk
import json
import ordklasstaggning

# En väldigt enkel grammatik för chunkning
chunkningsgrammatik = """
    NP: {<DT|PS>?<JJ>*<NN>}
"""

def main():
    # Kontrollera att ett filnamn (för ordklass-statistiken) har angetts på kommando-raden och att den angivna filen
    # existerar
    if len(sys.argv) < 3:
        print("Du måste som första argument ange sökvägen till en fil med ordklassstatistik. Den ska sluta med _ordklasstatistik.txt. Programmet avslutas, försök igen. Som andra argument måste du ange en fil med meningar som ska chunkas.".encode("utf8"))
        sys.exit(1)
    if not os.path.isfile(sys.argv[1]):
        print("Kan inte hitta den angivna filen med ordklasstatistik. (" + sys.argv[1] + ") Programmet avslutas, försök igen.".encode("utf8"))
        sys.exit(1)
    if not os.path.isfile(sys.argv[2]):
        print(("Kan inte hitta den angivna filen med meningar som ska chunkas. (" + sys.argv[1] + ") Programmet avslutas, försök igen.").encode("utf8"))
        sys.exit(1)

    # Hämta in ordklass-statistiken
    ordklassstatistikfilnamn =  sys.argv[1]
    ordklassdictionary = ordklasstaggning.hamta_ord_klass_statistik(ordklassstatistikfilnamn)

    # Läs in ord att chunka
    ord_att_chunka_fil = open(sys.argv[2])
    pp = pprint.PrettyPrinter(indent=4)
    for rad in ord_att_chunka_fil:
        rad_unicode = rad.strip()
        
        # Ordklass-tagga
        taggad = ordklasstaggning.hamta_ord_klasser(rad_unicode, ordklassdictionary)

        chunkningsparser = nltk.RegexpParser(chunkningsgrammatik)
        resultat = chunkningsparser.parse(taggad)
        print()
        print(resultat.pprint(indent=10))
        print()
        #resultat.draw() # To draw the tree, does not work remotely.


main()