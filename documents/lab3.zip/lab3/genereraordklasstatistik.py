#!/usr/bin/python
# -*- coding: utf-8 -*-

##################################################################
# Ett väldigt enkelt script för att räkna statistik för ordklasser
# Skrivet av Maria Skeppstedt för:
# Språkteknologi - Mänskliga språk och datorer
#################################################################

import sys
import json
import os

# Funktion för att generera ordklass-statistik
def hamta_ordklass_dictionary(annoteradfilnamn):
    annoteradfil = open(annoteradfilnamn, encoding = 'utf-8')

    ordklassdictionary = {}
    ny_rad = True
    for rad in annoteradfil:
        strippedrad = rad.strip()
        if strippedrad != "":
            ordposlist = strippedrad.split("\t")
            klass = ordposlist[0].strip()
            ord = ordposlist[1]
            if ny_rad:
                ord = ord.lower() # ord som inleder en mening görs om så att det bara innehåller gemener.
            if ord in ordklassdictionary:
                if klass in ordklassdictionary[ord]:
                    ordklassdictionary[ord][klass] = ordklassdictionary[ord][klass] + 1
                else:
                    ordklassdictionary[ord][klass] =  1
            else:
                ordklassdictionary[ord] = {}
                ordklassdictionary[ord][klass] =  1
            ny_rad = False
        else:
            ny_rad = True

    annoteradfil.close()
    return ordklassdictionary

    
def main():
    # Kontrollera att ett filnamn (för den annoterade filen) har angetts på kommando-raden och att den angivna filen
    # existerar
    if len(sys.argv) < 2:
        print("Du måste ange sökvägen till den fil som är annoterad med ordklasser. Programmet avslutas, försök igen.")
        sys.exit(1)
    if not os.path.isfile(sys.argv[1]):
        print("Kan inte hitta den angivna annoterade filen. (" + sys.argv[1] + ") Programmet avslutas, försök igen.")
        sys.exit(1)
    annoteradfilnamn =  sys.argv[1]

    # Anropa funktionen som skapar ordklass-statistiken
    ordklassdictionary = hamta_ordklass_dictionary(annoteradfilnamn)

    # Skapa ett namn för ordklass-statistikfilen. Om filen redan finns, fråga användaren om den ska skrivas över.
    namnbas = annoteradfilnamn.replace(".","").replace("/","").replace("\\","")
    ordklasstatistikfilnamn = namnbas + "_ordklasstatistik.txt"
    if os.path.isfile(ordklasstatistikfilnamn):
        val = input(("Filen " + ordklasstatistikfilnamn + " finns redan. Vill du ersätta den med en ny fil? Tryck i så fall j följt av enter: "))
        if val != "j":
            sys.exit(1)

    # Lagra ordklass-statistiken i en fil
    with open(ordklasstatistikfilnamn, 'w', encoding='utf8') as handtag:
        json.dump(ordklassdictionary, handtag, sort_keys=True, indent=4, ensure_ascii=False)


    print("Filen " + ordklasstatistikfilnamn + " har skapats.")

main()
            