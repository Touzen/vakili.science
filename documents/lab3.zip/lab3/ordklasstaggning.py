#!/usr/bin/python
# -*- coding: utf-8 -*-

###################################################
# Ett script som gör en väldigt enkel ordklasstaggning
# Skrivet av Maria Skeppstedt för:
# Språkteknologi - Mänskliga språk och datorer
###################################################

import sys
import os
import nltk
import json

# Gör ordklass-taggning för en token
def hamta_ord_klasser(val, ordklassdictionary):
    token_sekvens = []
    tokens = nltk.word_tokenize(val)
    for token in tokens:
        # börja med att kolla om tokenet finns som det är i statistiken
        # det sorterade dictionary med ordklasser som används sorteras efter den mest vanliga ordklassen, och denna returneras.
        if token in ordklassdictionary:
            token_sekvens.append((token, sorted([(item, key) for (key, item) in list(ordklassdictionary[token].items())], reverse=True)[0][1]))
        # kolla sedan om tokenet finns som gemener i statistiken
        elif token.lower() in ordklassdictionary:
            token_sekvens.append((token, sorted([(item, key) for (key, item) in list(ordklassdictionary[token.lower()].items())], reverse=True)[0][1]))
        elif token[0].isupper(): # Okänt och börjar på stor bokstav, då är det kanske ett namn
            token_sekvens.append((token, "PM")) 
        else:
            # Om det dyker upp ett token som inte har funnits i det manuellt annoterade datat, gissa på att det ska taggas med den vanligaste ordklassen, substantiv.
            token_sekvens.append((token, "NN"))
    return token_sekvens

# Funktion för att hämta in den tidigare lagrade ordklass-statistiken
def hamta_ord_klass_statistik(ordklassstatistikfilnamn):
    ordklassstatistikfil = open(ordklassstatistikfilnamn, 'r')
    ordklassdictionary = json.load(ordklassstatistikfil)
    ordklassstatistikfil.close()
    return ordklassdictionary

def main():
    # Kontrollera att ett filnamn (för ordklass-statistiken) har angetts på kommando-raden och att den angivna filen
    # existerar
    if len(sys.argv) < 3:
        print(("Du måste som första argument ange sökvägen till en fil med ordklassstatistik. Den ska sluta med _ordklasstatistik.txt. Som andra argument måste du ange en fil med meningar som ska ordklasstaggas. Programmet avslutas, försök igen."))
        sys.exit(1)
    if not os.path.isfile(sys.argv[1]):
        print(("Kan inte hitta den angivna filen med ordklasstatistik. (" + sys.argv[1] + ") Programmet avslutas, försök igen."))
        sys.exit(1)
    if not os.path.isfile(sys.argv[2]):
        print(("Kan inte hitta den angivna filen med meningar som ska taggas. (" + sys.argv[1] + ") Programmet avslutas, försök igen."))
        sys.exit(1)

    # Hämta in ordklass-statistiken
    ordklassstatistikfilnamn =  sys.argv[1]
    ordklassdictionary = hamta_ord_klass_statistik(ordklassstatistikfilnamn)

    # Läs in ord att tagga
    ord_att_tagga_fil = open(sys.argv[2])
    for rad in ord_att_tagga_fil:
        rad_unicode = rad.strip()
        taggad = hamta_ord_klasser(rad_unicode, ordklassdictionary)
        for word, tag in taggad:
            print(word, tag)
        print()

# En special-funktion i python, som säger att om programmet körs som huvudprogram (inte importerat i något annat), så ska main köras.
if __name__ == "__main__":
    main()
